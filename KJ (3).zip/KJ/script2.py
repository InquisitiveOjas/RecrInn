""" filename: script2.py """

# import parameters
# from time import sleep
# from selenium import webdriver
# from selenium.webdriver.common.keys import Keys

# driver = webdriver.Chrome('chromedriver')


# driver.get('https:www.google.com')
# sleep(3)

# search_query = driver.find_element_by_name('q')
# search_query.send_keys(parameters.search_query)
# sleep(0.5)

# search_query.send_keys(Keys.RETURN)
# sleep(3)

# linkedin_urls = driver.find_elements_by_class_name('iUh30')
# linkedin_urls = [url.text for url in linkedin_urls]
# sleep(0.5)

# # For loop to iterate over each URL in the list
# for linkedin_url in linkedin_urls:
# 	print(linkedin_url)

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import bs4
from time import sleep
 
browser = webdriver.Chrome('chromedriver')
browser.get('http://www.yahoo.com')
sleep(5)
assert 'Yahoo' in browser.title
 
elem = browser.find_element_by_name('p') # find the search box
res = elem.send_keys('site:linkedin.com/in/ AND "python developer" AND "London"' + Keys.RETURN)
 
soup = bs4.BeautifulSoup(browser.page_source, "html.parser")
linkElems = soup.select('a')
# for link in linkElems:
#     print(f'link: {link}')
numOpen = len(linkElems)
for i in range(numOpen):
    st=str(linkElems[i].get('href'))
    if (st.find(".linkedin.com") != -1):
      print(st)
 
browser.quit()
