skills=[]
l=[]
skills.append(skill)
for i in range(len(skills)):
    count=0
    for j in skills[i]:
        if j in post:
            count=count+1
    l.append(count)    



