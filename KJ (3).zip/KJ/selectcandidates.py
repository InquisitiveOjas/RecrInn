import xlrd
import os 
import io
import re
from pdfminer.converter import TextConverter
from pdfminer.pdfinterp import PDFPageInterpreter
from pdfminer.pdfinterp import PDFResourceManager
from pdfminer.pdfpage import PDFPage

def extract_text_from_pdf(pdf_path):
    resource_manager = PDFResourceManager()
    fake_file_handle = io.StringIO()
    converter = TextConverter(resource_manager, fake_file_handle)
    page_interpreter = PDFPageInterpreter(resource_manager, converter)
    with open(pdf_path, 'rb') as fh:
        for page in PDFPage.get_pages(fh,
                                      caching=True,
                                      check_extractable=True):
            page_interpreter.process_page(page)
        text = fake_file_handle.getvalue()
    # close open handles
    converter.close()
    fake_file_handle.close()
    if text:
        return text


pst="Data Science"

locate="fields.xlsx"
wb = xlrd.open_workbook(locate) 
sheet = wb.sheet_by_index(0)
for i in range(sheet.nrows): 
    # print(sheet.cell_value(i, 0)) 
    if(sheet.cell_value(i, 0)==pst):
        # print(sheet.cell_value(i, 1))
        val=sheet.cell_value(i, 1)
        break

loc="skills.xlsx"
pst="Data Science"
wb = xlrd.open_workbook(loc) 
l=[]
sheet = wb.sheet_by_index(0)
delimeters=" ",".",","
for i in range(sheet.nrows): 
    # print(sheet.cell_value(i, 0)) 
    if(sheet.cell_value(i, 0)==pst):
        # print(sheet.cell_value(i, 1))
        ll=sheet.cell_value(i, 1)
        l=re.split(';|,| ',ll)
        break
print(l)
d=[]
resumes=os.listdir(val)
print(resumes)
for resume in resumes:
    print(resume)
    c=int(0)
    p=[]
    words = extract_text_from_pdf(str(val)+'/'+str(resume))
    for i in l:
        if(words.find(i)!=-1):
            c=c+1
            print(i)
    
    p.append(c)
    p.append(str(resume))
    d.append(p)
d.sort()
d=d[::-1]
print(d)


    









    